// Run only the tests that were specified with a pattern or filename:
// jest my-test #or
// jest path/to/my-test.js

// Run tests that match this spec name (match against the name in describe or test, basically)
// jest -t name-of-spec
module.exports = {

    // automock: true,
    // Automatically clear mock calls and instances between every test
    clearMocks: true,
  
    // An array of glob patterns indicating a set of files for which coverage information should be collected
    collectCoverageFrom: ['src/**/*.js'],
  
    collectCoverage: true,
    // The directory where Jest should output its coverage files
    coverageDirectory: 'coverage',

    coverageThreshold: {
        global: {
          branches: 90,
          functions: 90,
          lines: 90,
          statements: -10
        }
    },

    // transform: {
    //     '.+\\.(css|styl|less|sass|scss|png|jpg|ttf|woff|woff2)$':
    //     'jest-transform-stub',
    //     '^.+\\.(js|jsx)?$': 'babel-jest'
    // },
  
    // An array of file extensions your modules use
    moduleFileExtensions: ['js', 'json'],
  
    // The paths to modules that run some code to configure or set up the testing environment before each test
    setupFiles: ['<rootDir>/enzyme.config.js'],

    // The glob patterns Jest uses to detect test files
    testMatch: ['**/?(*.)+(spec).js'],
    
    testPathIgnorePatterns: ['<rootDir>/node_modules/'],


    // testPathIgnorePatterns: ['/node_modules/', '/npm-build/'],
    
	//   unmockedModulePathPatterns: [
	//   	'<rootDir>/node_modules',
	//   	'<rootDir>/testConfig'
	//   ],
    moduleNameMapper: {
      '^.+\\.(scss|css)$': 'identity-obj-proxy'
    }
  };
  