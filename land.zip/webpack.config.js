const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const webpack = require('webpack');
const autoprefixer = require('autoprefixer');

var config = {
    entry: './src/index.js',
    output: {
        path: path.resolve(__dirname, 'dist'),
        filename: 'bundle.js',
        publicPath: '/'
    },
    resolve: {
        extensions: ['.js', '.jsx']
    },
    module: {
        rules: [
            {
                test: /\.js$/,
                loader: 'babel-loader',
                exclude: /node_modules/
            },
            {
                test: /\.css$/,
                use: [
                    {
                        loader: 'style-loader'
                    },
                    {
                        loader: 'css-loader'
                    },
                    {
                        loader: 'postcss-loader',
                        options: {
                            plugins: () => [
                                autoprefixer({
                                    browsers: [
                                        '>1%',
                                        'last 2 versions'
                                    ]
                                })
                            ]
                        }
                    }
                ]

            },
            {
                test: /\.(scss)$/,
                use: [
                    {
                        loader: 'style-loader'
                    },
                    {
                        loader: 'css-loader',
                        options: {
                            modules: true,
                            localIdentName: '[name]_[local]__[hash:base64:5]',
                            importLoaders: 2
                        }
                    },
                    {
                        loader: 'postcss-loader',
                        options: {
                            plugins: () => [
                                autoprefixer({
                                    browsers: [
                                        '>1%',
                                        'last 2 versions'
                                    ]
                                })
                            ]
                        }
                    },
                    {
                        loader: 'sass-loader'
                    },
                ]
            },
            {
                test: /\.(png|gif|jpe?g)$/,
                loader: 'url-loader?limit=8000&name=images/[name].[ext]'
            }
        ]
    }
}

module.exports = (env, argv) => {
    if (argv.mode === 'development') {
        config.devtool = 'cheap-module-eval-source-map';
        config.watch = true;
        config.plugins = [
            new HtmlWebpackPlugin({
                title: 'LAND',
                template: 'src/index.html'
            }),
            new webpack.HotModuleReplacementPlugin()
        ];
        config.devServer = {
            historyApiFallback: true,
            hot: true,
            open: true,
            overlay: true
        }
    }
    return config;
}
