import React from 'react';
import { mount, shallow } from 'enzyme';

import Chip from '@material-ui/core/Chip';
import FaceIcon from '@material-ui/icons/Face';

import Author from './author.component';
import Aux from '../../../lib/hoc/landAux.component';

it ('should return Aux with chips of author', () => {
    let authors = Array(1).fill({ firstName: 'test', lastName: 'test', id: 1 })
    const wrapper = mount(<Author authors={authors} />);
    expect(wrapper.find(Aux).containsMatchingElement).toHaveReturned;
});

it ('should delete author when clicked on remove button', () => {
    let authors = Array(1).fill({ firstName: 'test', lastName: 'test', id: 1 });
    const props = {
        remove: () => mockImplementation((author) => {
            author;
        })
    }
    const wrapper = shallow(<Author authors={authors}  remove={props.remove} />);
    wrapper.find(Chip).at(1).simulate('delete'); 
    expect(props.remove).toReturn('auuthor');
});
