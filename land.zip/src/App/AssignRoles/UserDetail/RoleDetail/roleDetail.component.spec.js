/*
 * File: roleDetail.component.spec.js
 * Project: land-react-ui
 * File Created: Tuesday, 19th March 2019 12:26:12 pm
 * Author: soundarya.atgondan (soundarya.atgondan@object-frontier.com)
 * -----
 * Last Modified: Saturday, 27th April 2019 11:03:49 am
 * Modified By: soundarya.atgondan (soundarya.atgondan@object-frontier.com>)
 */
import React from 'react';
import expect from 'expect';
import { shallow, mount } from 'enzyme';
import RoleDetail from './roleDetail.component';
import ReactMultiSelectCheckboxes from 'react-multiselect-checkboxes';
import { configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { Checkbox } from '@material-ui/core';

configure({ adapter: new Adapter() });

describe('RoleDetail', () => {
    const props = {
        role: [
            {
                classes: []
            }
        ],
        roleWithCourse: [
            {
                classes: [],
                "name": "EVALUATOR",
                "id": 3,
                "hasCourse": true
            }
        ],
        event: {
            target: {
                name: "COORDINATOR",
                checked: true
            }
        },
        buttonLabel: 'Courses',
    }

    it('should render roleDetail without crashing', () => {
        const wrapper = shallow(<RoleDetail role={['trainer', 'author', 'evaluator']} role={props.role} />);
        expect(wrapper.find('h2').text()).toEqual('ASSIGN ROLES');
    });

    it('should contain ReactMultiSelect component', () => {
        const wrapper = mount(<RoleDetail role={props.roleWithCourse} />);
        expect(wrapper.find(<ReactMultiSelectCheckboxes placeholderButtonLabel={props.buttonLabel} />)).toBeTruthy;
    });

    it('should invoke handleSelectRole() on selecting a role', () => {
        let roleClicked = jest.fn();
        const wrapper = shallow(<RoleDetail role={props.role} roleSelected={roleClicked} />);
        wrapper.find(Checkbox).simulate('change', props.event);
        expect(roleClicked).toHaveBeenCalled();
    })

    it('should render submit button', () => {
        const roleClicked = jest.fn();
        const wrapper = shallow(<RoleDetail role={props.role} roleClicked={roleClicked} />);
        const button = wrapper.find('#submit');
        expect(button.length).toBe(1);
        button.simulate('click');
    });
});
