/*
 * File: UserDetail.component.js
 * Project: land-react-ui
 * File Created: Monday, 8th April 2019 12:14:53 pm
 * Author: soundarya.atgondan (soundarya.atgondan@object-frontier.com)
 * -----
 * Last Modified: Thursday, 27th June 2019 3:41:08 pm
 * Modified By: soundarya.atgondan (soundarya.atgondan@object-frontier.com>)
 */

import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import CheckBox from '@material-ui/core/checkBox';
import HttpRequest from '../../service/HttpRequest';
import SearchUser from './search/searchUser';
import RoleDetail from '../UserDetail/RoleDetail/roleDetail.component';
import WrappedVirtualizedTable from './VirtualizedTable/VirtualizedTable';
import Styles from './styles/styles';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import classes from '../UserDetail/RoleDetail/roleDetail.scss';
import * as constants from './UserDetail.constants';
import axios from 'axios';

class UserDetail extends Component {

    state = {
        users: [],
        isInvalidSearch: false,
        errorMessage: null,
        container: [],
        isUserSelected: false,
        isCourseSelected: false,
        isRoleSelected: false,
        column: {},
        courses: [],
        roles: [],
        selectAll: false,
        isAllSelected: false,
        selectedUsers: {},
        selectedRoleCourse: [],
        selectedRole: [],
        userList: [],
        searchedUsers: [],
        selectedCourses: [],
        courseList: [],
        pageNumber: 0,


        userLength: null,
    }

    onToggleCourses = (columnName, userId, name) => {
        let users = [...this.state.users];
        users.map(user => {
            if (user.id === userId) {
                let roleCourses = user[columnName];
                roleCourses.map(course => {
                    if (course.name === name) {
                        course.active = !course.active;
                    }
                })
                console.log(roleCourses)
                this.updateCourseInfo(user, columnName, name);
            }
        })
        this.setState({ users: users });
    }

    updateCourseInfo = (user, columnName, name) => {
        let users = [];
        let userObj = {};
        let updatedUser = {};
        updatedUser.id = user.id;
        updatedUser.active = true;
        updatedUser.firstName = user.firstName;
        updatedUser.lastName = user.lastName;
        updatedUser.email = user.email;
        // updatedUser.roleActive = user.roleActive;
        updatedUser.role = {};
        let roleInfo = user.roles.find(role => {
            if (role.hasCourse) {
                return role.course.name === name;
            }
            return role.name === name
        })

        if (!roleInfo.hasCourse) {
            roleInfo.course = null;
            userObj.active = roleInfo.active;
        }
        if (roleInfo.hasCourse) {
            userObj.active = roleInfo.course.active;
        }
        console.log(roleInfo, userObj)
        updatedUser.role = roleInfo;

        userObj.user = updatedUser;
        users.push(userObj);
        axios.put('http://192.168.2.148:8080/land-api/api/v1/user/role/course', users).then(response => {
            console.log(response.data);
        })
    }

    onSearchUsers = (value, keyCode) => {

        let searchText = value.trim().toLowerCase();
        const searchTextLength = searchText.length;
        const specialCharacters = constants.REGEX_SPCL_CHAR_WITHOUT_COMMA;
        // const alphaNumeric = constants.ALPHA_NUMERIC;
        const numbers = constants.NUMBERS;
        const alphabets = constants.ALPHABETS;
        let validated = this.validateSearchText(searchText, searchTextLength, specialCharacters, numbers, alphabets);
        this.setState({
            errorMessage: validated.errorMessage,
            isInvalidSearch: validated.isInvalidSearch,
            pageNumber: 0
        });
        console.log(this.state.pageNumber)
        if (keyCode !== 13) {
            return;
        }
        // let validated = this.validateSearchText(searchText, searchTextLength, specialCharacters, numbers, alphabets);
        if (validated.isInvalidSearch) {
            this.getAllUsers(validated);
        }

        this.getSearchedUser(searchText, validated);
    }

    getAllUsers = (validated) => {
        let userList = [...this.state.userList];
        axios.get(`http://192.168.2.148:8080/land-api/api/v1/user/role/course?pageNumber=${this.state.pageNumber}&size=10`).then(response => {
            let users = this.constructUser(response.data);
            users.map(data => {
                this.selectedUserHandler(data);
            })
            this.setState({
                users: users,
                // pageNumber: this.state.pageNumber + 1,
                // isInvalidSearch: validated.isInvalidSearch,
                // errorMessage: validated.errorMessage,
                userList: userList
            });
        });

    }

    getSearchedUser = (searchText, validated) => {
        let userList = [...this.state.userList];
        axios.get(`http://192.168.2.148:8080/land-api/api/v1/user/role/course/search?pageNumber=${this.state.pageNumber}&q=${searchText}&size=10`).then(response => {
            let users = this.constructUser(response.data);
            users.map(data => {
                this.selectedUserHandler(data);
            })
            this.setState({
                users: users,
                // isInvalidSearch: validated.isInvalidSearch,
                // errorMessage: validated.errorMessage,
                userList: userList
            });
        });
        console.log(users)
    }

    selectedUserHandler = (individualData) => {
        let userList = [...this.state.userList];
        userList.map(user => {
            if (individualData.id === user.id) {
                // individualData.checkedList.selected = true;
                individualData.checkedList.selected = !individualData.checkedList.selected;
            }
        });
        return userList;
    }

    validateSearchText = (searchText, searchTextLength, specialCharacters, numbers, alphabets) => {
        let isInvalidSearch;
        let errorMessage;
        if (!searchText) {
            // errorMessage = constants.ERR_MSG.INPUT_ERR_MSG;
            isInvalidSearch = true;
        } else if (searchTextLength >= 40) {
            errorMessage = constants.ERR_MSG.TEXT_LENGTH_ERR;
            isInvalidSearch = true;
        } else if (specialCharacters.test(searchText)) {
            errorMessage = constants.ERR_MSG.MAX_CHAR_ERR;
            isInvalidSearch = true;
        }
        // else if (numbers.test(searchText) && (alphabets.test(searchText))) {
        //     errorMessage = "Alphanumerics not allowed";
        //     isInvalidSearch = true;
        // }
        else {
            isInvalidSearch = false;
        }
        return { isInvalidSearch, errorMessage };
    }

    onSelectAll = isUserSelected => {
        if (isUserSelected) {
            this.setState(prevState => ({
                selectAll: !prevState.selectAll,
                isUserSelected: true,
                isAllSelected: true,
            }), () => {
                let users = this.onSelectAllUser()
                this.setState({ users: users })
            });
        }
        else {
            this.setState(prevState => ({
                selectAll: !prevState.selectAll,
                isAllSelected: false,
            }), () => {
                let users = this.onSelectAllUser()
                this.setState({ users: users })
            });
        }
    };

    onSelectAllUser = () => {
        let users = [...this.state.users];
        users.map(user => {
            let updatedcheckedList = user.checkedList;
            updatedcheckedList.selected = false;
        });
        return users;
    };


    onFilterCourse = (selectedCourses) => {
        let courses = [...this.state.courses];

        let filteredCourse = courses;
        if (selectedCourses.length > 0) {
            let courseIndex = filteredCourse.findIndex(filteredCourses => filteredCourses === selectedCourses[selectedCourses.length - 1]);
            filteredCourse.splice(courseIndex, 1);
            filteredCourse.unshift(selectedCourses[selectedCourses.length - 1]);
        }

        this.setState({ courses: filteredCourse });
    }

    isRoleCourseEmpty = (role, roles, selectedRolesCourses, coursesSelected) => {
        if (role.course.length === 0) {
            selectedRolesCourses.pop(coursesSelected);
            roles.map((role) => {
                if (coursesSelected.course.length === 0) {
                    role.classes = [classes.roleLabel];
                }
            })
        }
    }

    isRoleExist = (coursesData, roleName, roles, coursesSelected) => {
        let selectedRolesCourses = [...this.state.selectedRoleCourse];
        let isRoleExist = selectedRolesCourses.some(selectedRoleCourse => { return selectedRoleCourse.name === roleName });
        if (isRoleExist) {
            selectedRolesCourses.map((role) => {
                if (role.name === roleName) {
                    role.course = [...coursesData];
                    this.isRoleCourseEmpty(role, roles, selectedRolesCourses, coursesSelected);
                }
            })
        } else {
            selectedRolesCourses.push(coursesSelected);
            roles.map((role) => {
                if (coursesSelected.name === role.name) {
                    role.classes.push(classes.highlightRoleLabel);
                }
            })
        }

        this.setState({ selectedRoleCourse: selectedRolesCourses })
    }

    onSelectCourse = (selectedCourses, role) => {
        let roleName = role.name;
        let roles = [...this.state.roles];
        let courseList = [];
        selectedCourses.map((course) => {
            let newCourse = {};
            newCourse.id = course.value;
            newCourse.name = course.label;
            newCourse.description = course.description;
            newCourse.active = true;
            courseList.push(newCourse);
        })

        this.onFilterCourse(selectedCourses);

        let coursesSelected = {};
        let coursesData = [...courseList];
        let rolesData = [...roles];
        rolesData.map(roleData => {
            if (roleName === roleData.name) {
                coursesSelected.id = roleData.id;
            }
        })
        coursesSelected.name = roleName;
        coursesSelected.hasCourse = role.hasCourse;
        coursesSelected.courses = coursesData;
        this.isRoleExist(coursesData, roleName, roles, coursesSelected);

        this.setState({ isCourseSelected: true })
    };

    onSelectRole = (name, isRoleSelected) => {
        const roleName = name;
        let roles = [...this.state.roles];
        let newRole = {};
        roles.map((role) => {
            if (role.name === roleName) {
                newRole.id = role.id;
                newRole.name = role.name;
                newRole.hasCourse = role.hasCourse;
            }
        })
        let selectedRoles = [...this.state.selectedRole];
        if (!isRoleSelected) {
            selectedRoles.pop(newRole);
            roles.map((role) => {
                if (selectedRoles.length === 0) {
                    role.classes = [classes.roleLabel];
                }
            })
        } else {
            selectedRoles.push(newRole);
            roles.map((role) => {
                if (newRole.name === role.name) {
                    role.classes.push(classes.highlightRoleLabel);
                }
            })
        }

        this.setState({
            isRoleSelected: true,
            selectedRole: selectedRoles,
            roles: roles
        });
    };

    constructToaster = () => {
        if ((this.state.isRoleSelected || this.state.isCourseSelected) && this.state.isUserSelected) {
            toast.success(constants.SUCCESS_MESSAGE, {
                position: constants.TOP_CENTER,
                autoClose: 2000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
            });
        } else {
            toast.error(constants.ERROR_MESSAGE, {
                position: constants.TOP_CENTER,
                autoClose: 2000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
            });
        }
    }

    onSubmit = () => {
        this.constructToaster();
        let selectedUser = this.state.selectedRoleCourse.concat(this.state.selectedRole);
        let submitUsers = [...this.state.userList];
        let submitData = [];
        submitUsers.map((users) => {
            let userContent = {};
            userContent.id = users.id;
            userContent.firstName = users.firstName;
            userContent.lastName = users.lastName;
            userContent.email = users.email;
            userContent.roles = selectedUser;
            userContent.active = true;
            submitData.push(userContent);
        })
        console.log(submitData)
        let finalData = this.onSubmitRoles(submitData);
        console.log(finalData)
        axios.put('http://192.168.2.148:8080/land-api/api/v1/user/role/course', finalData).then(response => {
            console.log(response.data);
        })
    };

    onSubmitRoles = (userData) => {
        console.log(userData)
        let finalUsers = [];
        userData[0].roles.map(role => {
            console.log(role);
            let individualUser = {};
            individualUser.id = userData[0].id;
            individualUser.firstName = userData[0].firstName;
            individualUser.lastName = userData[0].lastName;
            individualUser.email = userData[0].email;
            individualUser.role = {};
            individualUser.role.id = role.id;
            individualUser.role.name = role.name;
            individualUser.role.courses = role.courses[0];
            console.log(individualUser.role.courses)
            finalUsers.push(individualUser);
            console.log(finalUsers);
            return finalUsers;
        });
    }

    getCourses = () => {
        let courseList = [];
        axios.get('http://192.168.2.148:8080/land-api/api/v1/course').then(response => {
            response.data.forEach(course => {
                let courseContent = {};
                courseContent.label = course.name;
                courseContent.value = course.id;
                courseContent.description = course.description;
                courseList.push(courseContent);
            });
            this.setState({ courses: courseList })
        }).catch(error => {
            console.log(error)
        });
    }

    getRoles = () => {
        let roleList = [];

        axios.get('http://192.168.2.148:8080/land-api/api/v1/role').then(response => {
            response.data.forEach(role => {
                let roleContent = {};
                roleContent.name = role.name;
                roleContent.id = role.id;
                roleContent.hasCourse = role.hasCourse;
                roleContent.classes = [];
                roleList.push(roleContent);
            });
            this.setState({ roles: roleList })
        }).catch(error => {
            //handle error
        });
    }

    componentDidMount() {
        this.getCourses();
        this.getRoles();

        axios.get(`http://192.168.2.148:8080/land-api/api/v1/user/role/course?pageNumber=${this.state.pageNumber}&size=10`).then(response => {
            let users = this.constructUser(response.data);
            this.setState(prevState => {
                return {
                userLength: users.length,
                users: users,
                pageNumber: prevState.pageNumber + 1
                }
            })
        }).catch(error => {
            // handle error
        })
    }

    constructUser = (users) => {
        let actualUsers = [];
        users.map(indiv => {
            let alreadyExist = actualUsers.find(each => each.id === indiv.user.id);
            if (alreadyExist) {
                let index = actualUsers.indexOf(alreadyExist);
                if (indiv.user.role) {
                    if (indiv.user.role.hasCourse) {
                        indiv.user.role.course.active = indiv.active
                    } else {
                        indiv.user.role.active = indiv.active;
                    }
                    alreadyExist.roles.push(indiv.user.role);
                    actualUsers.splice(index, 1);
                    actualUsers.push(alreadyExist);
                }
            } else {
                let individualUser = {};
                let checkedList = {};
                checkedList.id = indiv.user.id;
                checkedList.selected = false;
                individualUser.checkedList = checkedList;
                individualUser.firstName = indiv.user.firstName;
                individualUser.id = indiv.user.id;
                individualUser.email = indiv.user.email;
                individualUser.lastName = indiv.user.lastName;
                individualUser.roles = [];
                if (indiv.user.role) {
                    if (indiv.user.role.hasCourse) {
                        indiv.user.role.course.active = indiv.active;
                    } else {
                        indiv.user.role.active = indiv.active;
                    }
                    individualUser.roles.push(indiv.user.role);
                    actualUsers.push(individualUser);
                }
            }
        });
        return this.constructCourses(actualUsers);
    }

    constructCourses = (users) => {
        users.forEach(user => {
            user.Trainer = [];
            user.Evaluator = [];
            user.Author = [];
            user.Reviewer = [];
            user.Misc = [];
            user.roles.map(role => {
                if (role.hasCourse) {
                    switch (role.name) {
                        case "Trainer":
                            role.course.userId = user.id;
                            user.Trainer.push(role.course);
                            break;
                        case "Evaluator":
                            role.course.userId = user.id;
                            user.Evaluator.push(role.course);
                            break;
                        case "Author":
                            role.course.userId = user.id;
                            user.Author.push(role.course);
                            break;
                        case "Reviewer":
                            role.course.userId = user.id;
                            user.Reviewer.push(role.course);
                            break;
                    }
                } else {
                    if (role.name) {
                        role.userId = user.id;
                        user.Misc.push(role)
                    }
                }
            });
        });
        return users;
    }

    onDeleteCourse = (columnName, userId, name) => {
        let users = [...this.state.users];
        users.map(user => {
            if (user.id === userId) {
                let roleCourses = user[columnName];
                console.log(roleCourses)
                // roleCourses.map(( course, index ) => {
                //     if (course.name === name) {
                //         let role = user.roles.find(role => {
                //             return role.name === columnName;
                //         })
                //         axios.delete('http://192.168.2.148:8080/land-api/api/v1/user/' + userId +'/role/'+ role.id +'/course/' + course.id).then(response => {
                //             console.log(response.data);
                //             roleCourses.splice(index, 1);
                //             user[columnName] = roleCourses;
                //             this.setState ({ users: users });
                //         })
                //     } 
                // });
                user.roles.map((role, index) => {
                    if (role.hasCourse) {
                        roleCourses.map((course, index) => {
                            if (course.name === name) {
                                let role = user.roles.find(role => {
                                    return role.name === columnName;
                                })
                                axios.delete('http://192.168.2.148:8080/land-api/api/v1/user/' + userId + '/role/' + role.id + '/course/' + course.id).then(response => {
                                    console.log(response.data);
                                    roleCourses.splice(index, 1);
                                    user[columnName] = roleCourses;
                                    this.setState({ users: users });
                                })
                            }
                        });
                    } else {
                        let course = {};
                        course.id = null;
                        axios.delete('http://192.168.2.148:8080/land-api/api/v1/user/' + userId + '/role/' + role.id + '/course/' + course.id).then(response => {
                            console.log(response.data);
                            roleCourses.splice(index, 1);
                            user[columnName] = roleCourses;
                            this.setState({ users: users });
                        })
                    }
                });


            }
        })
    }

    onUserSelected = (userId) => {
        let users = [...this.state.users];
        let selectedUser = {};
        let userList = [...this.state.userList];
        let isAllSelected = this.state.isAllSelected;
        if (isAllSelected) {
            users.map(user => {
                let updatedcheckedList = user.checkedList;
                updatedcheckedList.selected = (user.id !== userId);
            });
        } else {
            users.map(user => {
                if (user.id === userId) {
                    selectedUser = user;
                    let updatedcheckedList = selectedUser.checkedList;
                    updatedcheckedList.selected = !updatedcheckedList.selected;
                }
            });
        }
        userList.push(selectedUser);
        this.setState({
            users: users,
            isUserSelected: true,
            isAllSelected: false,
            selectedUsers: selectedUser,
            userList: userList
        });
    }

    onOffsetReached = (flag) => {
        let users = [...this.state.users];
        console.log('offsetReached')
        if (flag) {
            console.log('making ajax');
            // this.setState({  });
            axios.get(`http://192.168.2.148:8080/land-api/api/v1/user/role/course?pageNumber=${this.state.pageNumber}&size=10`)
                .then(response => {
                    const finalUsers = users.concat(this.constructUser(response.data));
                    console.log('final users', finalUsers);
                    this.setState(prevState => {
                        console.log('prevState', prevState)
                        return {
                            users: finalUsers,
                            userLength: finalUsers.length,
                            pageNumber: prevState.pageNumber + 1,
                            // prevReqCompltd: true
                        }
                    })
                })
                // .catch(err => this.setState({ prevReqCompltd: true }))
        }
        
    }

    getWrappedVirtualizedTable = () => {
        let { users, searchedUsers } = this.state;
        if (searchedUsers.length > 0) {
            users = searchedUsers;
        }
        return (<WrappedVirtualizedTable
            rowCount={users.length}
            rowGetter={({ index }) => users[index]}
            onToggleCourses={this.onToggleCourses}
            selectAll={this.state.selectAll}
            handleDeleteCourse={this.onDeleteCourse}
            onUserSelected={this.onUserSelected}
            isAllSelected={this.state.isAllSelected}
            onOffsetReached={this.onOffsetReached}
            userLength={this.state.userLength}
            columns={[
                {
                    width: 180,
                    label: <CheckBox onChange={(event) => this.onSelectAll(event.target.checked)} />,
                    dataKey: constants.CHECKED_LIST,
                    numeric: false
                },
                {
                    width: 150,
                    label: constants.HEADER.ID,
                    dataKey: constants.DATAKEY.ID,
                    numeric: true
                },
                {
                    width: 180,
                    label: constants.HEADER.FIRST_NAME,
                    dataKey: constants.DATAKEY.FIRSTNAME,
                    numeric: false,
                },
                {
                    width: 180,
                    label: constants.HEADER.LAST_NAME,
                    dataKey: constants.DATAKEY.LASTNAME,
                    numeric: false,
                },
                {
                    width: 180,
                    label: constants.HEADER.TRAINER,
                    dataKey: constants.DATAKEY.TRAINER,
                    numeric: false,
                },
                {
                    width: 180,
                    label: constants.HEADER.EVALUATOR,
                    dataKey: constants.DATAKEY.EVALUATOR,
                    numeric: false,
                },
                {
                    width: 180,
                    label: constants.HEADER.AUTHOR,
                    dataKey: constants.DATAKEY.AUTHOR,
                    numeric: false,
                },
                {
                    width: 180,
                    label: constants.HEADER.REVIEWER,
                    dataKey: constants.DATAKEY.REVIEWER,
                    numeric: false,
                },
                {
                    width: 180,
                    label: constants.HEADER.MISC,
                    dataKey: constants.DATAKEY.MISC,
                    numeric: false,
                },
            ]}
        />);
    }

    render() {
        return (
            <div>
                <SearchUser
                    {...this.props}
                    searching={this.onSearchUsers}
                    searchValidate={this.state.isInvalidSearch}
                    errorMessage={this.state.errorMessage}
                />
                <div>
                    <div className={classes.roleHeader}>
                        <h3 className={classes.roleHeading}>
                            ROLES
                    </h3>
                    </div>
                    <Paper className={classes.tableView}>
                        {this.getWrappedVirtualizedTable()}
                    </Paper>
                </div>
                {this.state.isUserSelected ? (<RoleDetail courses={this.state.courses}
                    role={this.state.roles}
                    isCourseSelected={this.state.isCourseSelected}
                    isRoleSelected={this.state.isRoleSelected}
                    onSubmit={this.onSubmit.bind(this)}
                    onCourseSelected={this.onSelectCourse.bind(this)}
                    roleSelected={this.onSelectRole.bind(this)}
                />) : null}
                <ToastContainer />
            </div>
        );
    }
}

export default withStyles(Styles)(UserDetail);
