/*
 * File: UserDetail.constants.js
 * Project: land-react-ui
 * File Created: Tuesday, 19th March 2019 12:26:12 pm
 * Author: soundarya.atgondan (soundarya.atgondan@object-frontier.com)
 * -----
 * Last Modified: Friday, 21st June 2019 12:37:59 pm
 * Modified By: soundarya.atgondan (soundarya.atgondan@object-frontier.com>)
 */
export const REGEX_SPCL_CHAR_WITHOUT_COMMA = /[ !@#$%^&*()_+\-[\]{};':'\\|.<>/?= ]/;
export const REGEX_SPCL_CHAR = /[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;
export const ALPHA_NUMERIC = /[a-zA-Z0-9]/;
export const NUMBERS = /[0-9,]/;
export const ALPHABETS = /[a-z,]/;

export const ERR_MSG = {
    INPUT_ERR_MSG: 'please enter valid input',
    TEXT_LENGTH_ERR: 'Only 40 characters allowed',
    MAX_CHAR_ERR: 'no special characters allowed'
};

export const HEADER = {
    ID: 'ID',
    FIRST_NAME: 'FIRST NAME',
    LAST_NAME: 'LAST NAME',
    TRAINER: 'TRAINER',
    EVALUATOR: 'EVALUATOR',
    AUTHOR: 'AUTHOR',
    REVIEWER: 'REVIEWER',
    MISC: 'MISC'
};

export const DATAKEY = {
    ID: 'id',
    FIRSTNAME: 'firstName',
    LASTNAME: 'lastName',
    TRAINER: 'Trainer',
    EVALUATOR: 'Evaluator',
    AUTHOR: 'Author',
    REVIEWER: 'Reviewer',
    MISC: 'Misc'
};

export const CHECKED_LIST = 'checkedList';

export const SUCCESS_MESSAGE = 'Role Assigned Successfully';
export const TOP_CENTER = 'top-center';
export const ERROR_MESSAGE = 'Please select a role and (or) course';
