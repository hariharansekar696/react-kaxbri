/*
 * File: VirtualizedTable.js
 * Project: land-react-ui
 * File Created: Tuesday, 19th March 2019 12:26:12 pm
 * Author: soundarya.atgondan (soundarya.atgondan@object-frontier.com)
 * -----
 * Last Modified: Thursday, 27th June 2019 4:10:40 pm
 * Modified By: soundarya.atgondan (soundarya.atgondan@object-frontier.com>)
 */
import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import { withStyles, createMuiTheme, MuiThemeProvider } from '@material-ui/core/styles';
import TableCell from '@material-ui/core/TableCell';
import { AutoSizer, Column, Table } from 'react-virtualized';
import Checkbox from '@material-ui/core/Checkbox';
import Icons from '../icons/icons';
import Styles from '../styles/styles';

const theme = createMuiTheme({
    overrides : {
        MuiTableCell : {
            root :{
                display: 'flex',
                flexDirection: 'column'
            }
        }
    }
  });

class MuiVirtualizedTable extends React.PureComponent {
    constructor(props) {
        super(props);
        this.forceUpdate();
    }
    state = {
        users: [],
        offsetReached: false,
        height: 300,
        rowHeight: 40,
        width: 550,
        overCount: 1,
    }

    componentDidUpdate = (prevProps, prevState) => {

        if (this.state.offsetReached) {
            let offsetReached = {...this.state.offsetReached};
            let userLength = [this.props.userLength];
            offsetReached = false;

            this.setState({ users: userLength, offsetReached: offsetReached });
        }


        // if (prevProps.userLength > prevState.userLength) {
        //     console.log("in")
        //     // let newUsers = [...prevProps.userLength];
        //     // this.setState({ users: newUsers });
        // }
    }

    getRowClassName = ({index}) => {
        const {classes, rowClassName}  = this.props;
        return classNames(classes.tableRow, classes.flexContainer, rowClassName, {
            [classes.tableRowHover]: index !== -1 
        } );
    };

    cellRenderer = ({cellData, columnIndex = null}) => {
        const {columns, classes, rowHeight, onRowClick} = this.props;
        let cellInfo = [];
        if (cellData) {
            if (columnIndex === 0) {
                let onUserSelected = this.props.isAllSelected ? this.props.isAllSelected : cellData.selected
                cellInfo.push( 
                    <Checkbox checked = {onUserSelected} onClick = {() => this.props.onUserSelected(cellData.id)}/>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
                    );
                }
            }     
            this.cellDataRenderer(cellData, columnIndex, columns, cellInfo);
            return (
                <MuiThemeProvider theme={theme}>
                <TableCell
                component='div'
                className={classNames(classes.tableCell, classes.flexContainer, {
                    [ classes.noClick ]: onRowClick === null,
                })}
                variant='body'
                style={{height: rowHeight}}
                >
                { cellInfo }
            </TableCell>
             </MuiThemeProvider>
        );
    };
    
    cellDataRenderer = (cellData, columnIndex, columns, cellInfo) => {
        const { classes } = this.props;
        if (typeof cellData === 'object' && columnIndex !== 0) {
            cellData.map(data => {
                cellInfo.push(
                    <div className = {classes.courses}>
                        { data.name }
                        <Icons 
                            onToggleCourses  = {() => this.props.onToggleCourses(columns[columnIndex].dataKey, data.userId, data.name)} 
                            toggleCourses = {data.active} 
                            deleteCourse = {() => this.props.handleDeleteCourse(columns[columnIndex].dataKey, data.userId, data.name)}
                            />
                    </div>
                );
            } );
        }
        
        if (columnIndex !== 0 && typeof cellData !== 'object') {
            cellInfo.push(cellData);
        }
    }

    headerRenderer = ({ label }) => {
        const { headerHeight, classes } = this.props;
        const inner =
            <div>
                { label }
            </div>

        return (
            <MuiThemeProvider theme={theme}>
            <TableCell
                component='div'
                className={ classNames(classes.tableCell, classes.flexContainer, classes.noClick) }
                variant='head'
                style={{ height: headerHeight }} 
            >
                { inner }
            </TableCell>
            </MuiThemeProvider> 
        );
    };

    onRowsRendered = ({stopIndex}) => {
        if ((stopIndex === (this.props.userLength -1)) && !this.state.offsetReached) {
            let offsetReached = true;               
            this.props.onOffsetReached(offsetReached);
            this.setState({ offsetReached: offsetReached })
        }
    }

    render() {
        const { classes, columns, ...tableProps } = this.props;
        return (
           
            <AutoSizer>
                {({height, width}) => (
                    <Table
                        className={classes.table}
                        height={height}
                        width={width}
                        {...tableProps}
                        rowClassName={this.getRowClassName}
                        onRowsRendered={this.onRowsRendered}
                    >
                        {columns.map(({cellContentRenderer = null, className, dataKey, ...other }, index) => {
                            let renderer;
                            if (cellContentRenderer) {
                                renderer = cellRendererProps => {
                                    console.log(cellRendererProps)
                                    this.cellRenderer({
                                        cellData: cellContentRenderer(cellRendererProps),
                                        columnIndex: index,
                                    });
                                }
                            } else {
                                renderer = this.cellRenderer;
                            }
                            return (
                                <Column
                                    key={ dataKey }
                                    headerRenderer={headerProps => 
                                        this.headerRenderer({
                                            ...headerProps,
                                            columnIndex: index,
                                        })
                                    }
                                    className={ classNames( classes.flexContainer, className ) }
                                    cellRenderer={ renderer }
                                    dataKey={ dataKey }
                                    {...other}
                                />
                            );
                        })}
                    </Table>
                )}
            </AutoSizer>
        );
    }
}


MuiVirtualizedTable.propTypes = {
    classes: PropTypes.object.isRequired,
    columns: PropTypes.arrayOf(
        PropTypes.shape({
        cellContentRenderer: PropTypes.func,
        dataKey: PropTypes.string.isRequired,
        width: PropTypes.number.isRequired,
        }),
    ).isRequired,
    headerHeight: PropTypes.number,
    onRowClick: PropTypes.func,
    rowClassName: PropTypes.string,
    rowHeight: PropTypes.oneOfType([PropTypes.number, PropTypes.func]),
};

MuiVirtualizedTable.defaultProps = {
    headerHeight: 56,
    rowHeight: 75,
};

const WrappedVirtualizedTable = withStyles(Styles)(MuiVirtualizedTable);

export default WrappedVirtualizedTable;
