export const ERROR = 'error';

export const REGEX_NUM = /\d/;
export const REGEX_ALPHABETS = /^[a-zA-Z \b]+$/;
