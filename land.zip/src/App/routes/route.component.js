import React from 'react';
import { Switch, Redirect } from 'react-router-dom';

import Router from './route.config';
import RouteWithSubRoutes from './routeWithSubRoutes.component';

/*
 * File: route.component.js
 * Project: land-react-ui
 * File Created: Monday, 25th March 2019 10:06:30 am
 * Author: Shahul Hameed M D (shahul.shaik@object-frontier.com)
 * -----
 * Last Modified: Friday, 3rd May 2019 11:14:20 am
 * Modified By: Shahul Hameed M D (shahul.shaik@object-frontier.com)
 * -----
 * Copyright 2019 Object Frontier Software Pvt. Ltd
 */

class Routes extends React.Component {
    render() {
        return (
            <Switch>
                {Router.map(props => {
                    if (props) {
                        return <RouteWithSubRoutes key={props.path} {...props} />
                    }
                })}
                {/* <Redirect to='/addcourse' /> */}
            </Switch>
        );
    }
}

export default Routes;
