import HttpRequest from './HttpRequest';
import axios from 'axios';

test ( 'testing HttpRequest for get()', () => {
    axios.get = jest.fn().mockImplementationOnce( () => Promise.resolve ( {  
        data: [ 'test data get' ]
    } ) );

    const url = HttpRequest.get();
    url.then(resp => expect(resp.data).toEqual( [ 'test data get' ] ) );
} );

test('testing HttpRequest for post()', () => {
    axios.post = jest.fn().mockImplementationOnce(() => Promise.resolve({
        data: [ 'test data post' ]
    }));

    const response = HttpRequest.post();
    response.then(resp => expect(resp.data.toEqual([ 'test data post' ])));
});
