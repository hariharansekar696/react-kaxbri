import React from 'react';
import axios from 'axios';

/*
 * File: HttpRequest.js
 * Project: land-react-ui
 * File Created: Monday, 25th March 2019 10:06:30 am
 * Author: Shahul Hameed M D (shahul.shaik@object-frontier.com)
 * -----
 * Last Modified: Friday, 3rd May 2019 11:27:00 am
 * Modified By: Shahul Hameed M D (shahul.shaik@object-frontier.com)
 * -----
 * Copyright 2019 Object Frontier Software Pvt. Ltd
 */

class HttpRequest extends React.Component {
    static urlPaths = require('../../../config.json');

    static get = (url) => {
        return axios.get(HttpRequest.urlPaths.baseUrl.url + url);
    }

    static post = (url, payLoad) => {
        return axios.post(HttpRequest.urlPaths.baseUrl.url + url, payLoad);
    }
}

export default HttpRequest;
