import React, { Component } from 'react';

import Routes from './routes/route.component';
import Header from './HeaderContainer/Header.container';
import SideMenu from './MainContainer/SideMenu.container';
import classes from './MainContainer/MainContainer.container.scss';

class App extends Component {
  render() {
    return(
      <div>
        <Header />
        <div className={classes.mainContainer}>
          <SideMenu />
          <div className={classes.contentSection}>
            <Routes />
          </div>
        </div>
      </div>
    );
  }
}

export default App;
