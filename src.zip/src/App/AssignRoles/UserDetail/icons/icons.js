/*
 * File: icons.js
 * Project: land-react-ui
 * File Created: Tuesday, 19th March 2019 12:26:12 pm
 * Author: soundarya.atgondan (soundarya.atgondan@object-frontier.com)
 * -----
 * Last Modified: Friday, 21st June 2019 2:07:23 pm
 * Modified By: soundarya.atgondan (soundarya.atgondan@object-frontier.com>)
 */
import React, { Component } from 'react';
import DeleteAlert from '../deleteAlert';
import Icon from '@material-ui/core/Icon';
import CourseActiveAlert from '../courseActiveAlert';

class Icons extends Component {
    state = {
        open: false,
        courseStatus: {
            confirmCourseStatus: false,
            dialogMessage: '',
        },
    }

    handleClickOpen = () => this.setState({ open: true })

    handleClose = () => this.setState({ open: false })

    handleDialog = (status) => {
        let courseStatus = {...this.state.courseStatus}
        courseStatus.confirmCourseStatus = status
        this.setState({ courseStatus: courseStatus })
    }

    confirmDelete = () => this.setState({ open: true })

    confirmCourseActive = (message) => {
        const courseStatus = {...this.state.courseStatus};
        courseStatus.confirmCourseStatus = true;
        courseStatus.dialogMessage = message;
        this.setState({ courseStatus: courseStatus })
    };

    toggleCourse = () => {
        this.handleDialog(false);
        this.props.onToggleCourses();
    }

    render() {
        let iconButton = null;
        if (this.props.toggleCourses) {
            iconButton = <Icon id={this.props.key}
                color='disabled'
                onClick={() => this.confirmCourseActive('Do you want to disable the course?')}
                // onClick={this.props.onToggleCourses}
                >remove_circle</Icon>
        } else {
            iconButton = <Icon id={this.props.key}
                color='secondary'
                onClick={() => this.confirmCourseActive('Do you want to Enable the course?')}
                // onClick={this.props.onToggleCourses}
                >add_circle</Icon>
        }
        return (
            <div>
                {this.state.courseStatus.confirmCourseStatus ?
                    <CourseActiveAlert courseStatus={this.state.courseStatus}
                        onToggleCourses={this.toggleCourse}
                        handleCourseClose={() => this.handleDialog(false)}
                        handleCourseOpen={() => this.handleDialog(true)} />
                    : <noscript />}
                <div>
                    {iconButton}
                    <Icon id={this.props.key}
                        color='error'
                        onClick={this.confirmDelete}
                    >delete</Icon>
                    {
                        this.state.open &&
                        <DeleteAlert open={this.state.open}
                            deleteCourse={this.props.deleteCourse}
                            handleClose={this.handleClose}
                            handleOpen={this.handleOpen}
                        />
                    }
                </div>
            </div>
        );
    }
}

export default Icons;
