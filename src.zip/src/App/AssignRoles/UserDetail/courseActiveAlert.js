/*
 * File: courseActiveAlert.js
 * Project: land-react-ui
 * File Created: Wednesday, 19th June 2019 11:37:28 am
 * Author: soundarya.atgondan (soundarya.atgondan@object-frontier.com)
 * -----
 * Last Modified: Friday, 21st June 2019 2:06:20 pm
 * Modified By: soundarya.atgondan (soundarya.atgondan@object-frontier.com>)
 */
import React from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import Slide from "@material-ui/core/Slide";

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

const courseActiveAlert = (props) => {
  return ( 
      <Dialog
        open={props.courseStatus.confirmCourseStatus}
        TransitionComponent={Transition}
        keepMounted
        aria-labelledby="alert-dialog-slide-title"
        aria-describedby="alert-dialog-slide-description"
      >
        <DialogContent>
          <DialogContentText id="alert-dialog-slide-description">
            {props.courseStatus.dialogMessage}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={props.onToggleCourses} color="primary">
            ok
          </Button>
          <Button onClick={props.handleCourseClose} color="primary">
            cancel
          </Button>
        </DialogActions>
      </Dialog>
  );
}

export default courseActiveAlert;
