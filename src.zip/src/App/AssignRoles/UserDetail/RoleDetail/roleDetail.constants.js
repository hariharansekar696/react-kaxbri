/*
 * File: roleDetail.constants.js
 * Project: land-react-ui
 * File Created: Tuesday, 19th March 2019 12:26:12 pm
 * Author: soundarya.atgondan (soundarya.atgondan@object-frontier.com)
 * -----
 * Last Modified: Saturday, 27th April 2019 11:03:57 am
 * Modified By: soundarya.atgondan (soundarya.atgondan@object-frontier.com>)
 */
export const SEARCH_COURSE = 'Search Courses';
export const COURSES = 'Courses';
export const SELECT_ROLE = 'selectRole';
export const SUBMIT = 'submit';
export const ROLE_DETAIL = 'roleDetail';
export const MULTISELECT = 'multiSelect';