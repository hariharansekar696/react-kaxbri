/*
 * File: searchUser.js
 * Project: land-react-ui
 * File Created: Tuesday, 19th March 2019 12:26:12 pm
 * Author: soundarya.atgondan (soundarya.atgondan@object-frontier.com)
 * -----
 * Last Modified: Tuesday, 25th June 2019 11:21:39 am
 * Modified By: soundarya.atgondan (soundarya.atgondan@object-frontier.com>)
 */
import React from 'react';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import InputBase from '@material-ui/core/InputBase';
import SearchIcon from '@material-ui/icons/Search';

const searchUser = (props) => {
    const { classes } = props;
    let error = props.searchValidate ? <label className={classes.searchError}>{props.errorMessage}</label> : null
    
    return (
        <div className={classes.root}>
            <AppBar position='relative'>
                <Toolbar>
                    <div className={classes.search}>
                        <div className={classes.searchIcon}>
                            <SearchIcon />
                        </div>
                        <InputBase
                            placeholder='Search for user'
                            classes={{
                                root: classes.inputRoot,
                                input: classes.inputInput,
                            }}
                            onKeyUp = {(event) => props.searching(event.target.value, event.keyCode)}
                            // onChange = {(event) => props.searching(event.target.value)}
                        />
                    </div>
                </Toolbar>
                { error }
            </AppBar>
        </div>
    );
}

export default searchUser;
