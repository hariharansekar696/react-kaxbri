/*
 * File: UserDetail.component.spec.js
 * Project: land-react-ui
 * File Created: Tuesday, 19th March 2019 12:26:12 pm
 * Author: soundarya.atgondan (soundarya.atgondan@object-frontier.com)
 * -----
 * Last Modified: Saturday, 27th April 2019 11:05:14 am
 * Modified By: soundarya.atgondan (soundarya.atgondan@object-frontier.com>)
 */
import React from 'react';
import { shallow, mount } from 'enzyme';
import renderer from 'react-test-renderer';

import UserDetail from './UserDetail.component.js';

describe('<UserDetail />', () => {

    it('should checks whether componentDidMount() is called', () => {
        const spy = jest.spyOn(UserDetail.prototype, 'componentDidMount');
        const wrapper = shallow(<UserDetail />).dive();
        wrapper.instance().componentDidMount();
        expect(spy).toHaveBeenCalled();
    });

    it('should render userDetail correctly', () => {
        const tree = renderer.create(<UserDetail />).toJSON();
        expect(tree).toMatchSnapshot();
    });

    it('should search for a user when entered for valid scenario', () => {
        const props = {
            event: {
                target: {
                    value: "Sound"
                },
                keyCode: 13
            }
        }
        const wrapper = shallow(<UserDetail />).dive();
        wrapper.instance().onSearchUsers(props.event.target.value, props.event.keyCode);
        expect(wrapper.state().isInvalidSearch).toBeFalsy();
    });

    it('should search for a user when entered for invalid scenario', () => {
        const props = {
            event: {
                target: {
                    value: "Sound%^*&**"
                },
                keyCode: 13
            }
        }
        const wrapper = shallow(<UserDetail />).dive();
        wrapper.instance().onSearchUsers(props.event.target.value, props.event.keyCode);
        expect(wrapper.state().isInvalidSearch).toBeTruthy();
    });

    it(' should search for a firstname when entered in valid scenario', () => {
        const props = {
            event: {
                target: {
                    value: "Sound"
                },
                keyCode: 13
            }
        }
        const wrapper = shallow(<UserDetail />).dive();
        const expected = Array(9).fill({ id: 1, firstName: "sound", lastName: 'karthi' });
        wrapper.setState({
            users: Array(9).fill({ id: 1, firstName: "sound", lastName: 'karthi' })
        })
        wrapper.instance().onSearchUsers(props.event.target.value, props.event.keyCode);
        expect(wrapper.state().users).toEqual(expected);
        expect(wrapper.state().users.length).toEqual(9);
    });

    it(' should search for a firstname when entered in invalid scenario', () => {
        const props = {
            event: {
                target: {
                    value: "Sound"
                },
                keyCode: 13
            }
        }
        const wrapper = shallow(<UserDetail />).dive();
        wrapper.setState({
            users: Array(9).fill({ id: 1, firstName: "karthick", lastName: "karthi" })
        })
        const expected = [];
        wrapper.instance().onSearchUsers(props.event.target.value, props.event.keyCode);
        expect(wrapper.state().searchedUsers).toEqual(expected);
    });

    it(' should search for a lastname when entered in valid scenario', () => {
        const props = {
            event: {
                target: {
                    value: "karthi"
                },
                keyCode: 13
            }
        }
        const wrapper = shallow(<UserDetail />).dive();
        const expected = Array(9).fill({ id: 1, firstName: "sound", lastName: 'karthi' });
        wrapper.setState({
            users: Array(9).fill({ id: 1, firstName: "sound", lastName: 'karthi' })
        })
        wrapper.instance().onSearchUsers(props.event.target.value, props.event.keyCode);
        console.log(wrapper.state().searchedUsers);
        expect(wrapper.state().searchedUsers).toEqual(expected);
    });

    it(' should search either a firstname or a lastname when entered', () => {
        const props = {
            event: {
                target: {
                    value: "s"
                },
                keyCode: 13
            }
        }
        const wrapper = shallow(<UserDetail />).dive();
        wrapper.setState({
            users: [
                {
                    id: 1,
                    firstName: 'sound',
                    lastName: 'test'
                },
                {
                    id: 2,
                    firstName: 'suchi',
                    lastName: 'test'
                },
                {
                    id: 3,
                    firstName: 'abi',
                    lastName: 'tet'
                }
            ]
        })
        wrapper.instance().onSearchUsers(props.event.target.value, props.event.keyCode);
        expect(wrapper.state().searchedUsers.length).toEqual(2);
    });

    it(' should search for a number when entered', () => {
        const props = {
            event: {
                target: {
                    value: '2'
                },
                keyCode: 13
            }
        }
        const wrapper = shallow(<UserDetail />).dive();
        wrapper.setState({
            users: [
                {
                    id: 1,
                    firstName: 'sound',
                    lastName: 'test'
                },
                {
                    id: 2,
                    firstName: 'suchi',
                    lastName: 'test'
                },
                {
                    id: 3,
                    firstName: 'abi',
                    lastName: 'tet'
                }
            ]
        })
        wrapper.instance().onSearchUsers(props.event.target.value, props.event.keyCode);
        expect(wrapper.state().searchedUsers.length).toEqual(1);
    });

    it(' should search for a user with empty field when entered', () => {
        const props = {
            event: {
                target: {
                    value: ''
                },
                keyCode: 13
            }
        }
        const wrapper = shallow(<UserDetail />).dive();
        wrapper.setState({
            users: Array(2).fill({ id: 1, firstName: "karthick", lastName: "karthi" })
        })
        wrapper.instance().onSearchUsers(props.event);
        expect(wrapper.state().users.length).toEqual(2);
    });

    it('Should enable the icon when the user is inactive', () => {

        const wrapper = shallow(<UserDetail />).dive();
        const props = {
            column: {
                dataKey: 'Trainer',
            },
            cellData: {
                userId: 1,
                name: 'react'
            },
            users: [
                {
                    id: 1,
                    Trainer: [
                        {
                            name: 'java',
                            isActive: true
                        },
                        {
                            name: 'react',
                            isActive: true
                        }
                    ],
                    Evaluator: [
                        {
                            name: 'java',
                            isActive: true
                        },
                        {
                            name: 'react',
                            isActive: true
                        }
                    ],
                    Author: [
                        {
                            name: 'java',
                            isActive: true
                        },
                        {
                            name: 'react',
                            isActive: true
                        }
                    ]
                }
            ]
        }
        wrapper.setState({
            users: props.users
        })
        wrapper.instance().onToggleCourses(props.column.dataKey, props.cellData.userId, props.cellData.name);
        expect(wrapper.state().users[0].Trainer[1].isActive).toBeFalsy();
    });

    it('Should enable the icon when the user is inactive', () => {

        const wrapper = shallow(<UserDetail />).dive();
        const props = {
            column: {
                dataKey: 'Trainer',
            },
            cellData: {
                userId: 1,
                name: 'react'
            },
            users: [
                {
                    id: 1,
                    Trainer: [
                        {
                            name: 'java',
                            isActive: true
                        },
                        {
                            name: 'react',
                            isActive: false
                        }
                    ],
                    Evaluator: [
                        {
                            name: 'java',
                            isActive: true
                        },
                        {
                            name: 'react',
                            isActive: true
                        }
                    ],
                    Author: [
                        {
                            name: 'java',
                            isActive: true
                        },
                        {
                            name: 'react',
                            isActive: true
                        }
                    ]
                }
            ]
        }
        wrapper.setState({
            users: props.users
        })
        wrapper.instance().onToggleCourses(props.column.dataKey, props.cellData.userId, props.cellData.name);
        expect(wrapper.state().users[0].Trainer[1].isActive).toBeTruthy();
    });

    it('Should enable the icon when the user is inactive', () => {

        const wrapper = shallow(<UserDetail />).dive();
        const props = {
            column: {
                dataKey: 'Trainer',
            },
            cellData: {
                userId: 1,
                name: 'go'
            },
            users: [
                {
                    id: 1,
                    Trainer: [
                        {
                            name: 'java',
                            isActive: true
                        },
                        {
                            name: 'react',
                            isActive: true
                        }
                    ],
                    Evaluator: [
                        {
                            name: 'java',
                            isActive: true
                        },
                        {
                            name: 'react',
                            isActive: true
                        }
                    ],
                    Author: [
                        {
                            name: 'java',
                            isActive: true
                        },
                        {
                            name: 'react',
                            isActive: true
                        }
                    ]
                }
            ]
        }
        wrapper.setState({
            users: props.users
        })
        wrapper.instance().onToggleCourses(props.column.dataKey, props.cellData.userId, props.cellData.name);
        expect(wrapper.state().users[0].Trainer[1].isActive).toBeTruthy();
    });

    it('Should select all users when the checkbox is clicked', () => {

        const props = {
            event: {
                target: {
                    checked: true
                }
            }
        }

        const wrapper = shallow(<UserDetail />).dive();

        const users = [
            {
                checkedList: {
                    selected: "true"
                }
            }
        ]

        wrapper.setState({
            selectAll: false,
            isUserSelected: false,
            isAllSelected: false,
            users: users
        })

        wrapper.instance().onSelectAll(props.event.target.checked);

        expect(wrapper.state().selectAll).toBeTruthy();
        expect(wrapper.state().isUserSelected).toBeTruthy();
        expect(wrapper.state().isAllSelected).toBeTruthy();
    });

    it('Should unselect all users when the checkbox is unselected', () => {

        const props = {
            event: {
                target: {
                    checked: false
                }
            }
        }

        const wrapper = shallow(<UserDetail />).dive();

        const users = [
            {
                checkedList: {
                    selected: true
                }
            }
        ]

        wrapper.setState({
            selectAll: true,
            isUserSelected: false,
            isAllSelected: true,
            users: users
        })

        wrapper.instance().onSelectAll(props.event.target.checked);

        expect(wrapper.state().selectAll).toBeFalsy();
        expect(wrapper.state().isUserSelected).toBeFalsy();
        expect(wrapper.state().isAllSelected).toBeFalsy();
    });

    it('should delete course when delete icon is clicked', () => {
        const wrapper = shallow(<UserDetail />).dive();
        const props = {
            column: {
                dataKey: 'Trainer'
            },
            cellData: {
                userId: 1,
                name: 'java'
            }
        };
        const users = [
            {
                id: 1,
                Trainer: [
                    {
                        name: 'java'
                    },
                    {
                        name: 'react'
                    }
                ],
                Evaluator: [
                    {
                        name: 'java'
                    },
                    {
                        name: 'react'
                    }
                ],
                Author: [
                    {
                        name: 'java'
                    },
                    {
                        name: 'react'
                    }
                ]
            }
        ]

        wrapper.setState({
            users: users
        })
        wrapper.instance().onDeleteCourse(props.column.dataKey, props.cellData.userId, props.cellData.name);
        expect(wrapper.state().users[0].Trainer).toHaveLength(1);
    })

    it('should delete course when delete icon is clicked', () => {
        const wrapper = shallow(<UserDetail />).dive();
        const props = {
            column: {
                dataKey: 'Trainer'
            },
            cellData: {
                userId: 2,
                name: 'java'
            }
        };
        const users = [
            {
                id: 1,
                Trainer: [
                    {
                        name: 'java'
                    },
                    {
                        name: 'react'
                    }
                ],
                Evaluator: [
                    {
                        name: 'java'
                    },
                    {
                        name: 'react'
                    }
                ],
                Author: [
                    {
                        name: 'java'
                    },
                    {
                        name: 'react'
                    }
                ]
            }
        ]

        wrapper.setState({
            users: users
        })
        wrapper.instance().onDeleteCourse(props.column.dataKey, props.cellData.userId, props.cellData.name);
        expect(wrapper.state().users[0].Trainer).toHaveLength(2);
    })

    it('should delete course when delete icon is clicked', () => {
        const wrapper = shallow(<UserDetail />).dive();
        const props = {
            column: {
                dataKey: 'Trainer'
            },
            cellData: {
                userId: 1,
                name: 'node'
            }
        };
        const users = [
            {
                id: 1,
                Trainer: [
                    {
                        name: 'java'
                    },
                    {
                        name: 'react'
                    }
                ],
                Evaluator: [
                    {
                        name: 'java'
                    },
                    {
                        name: 'react'
                    }
                ],
                Author: [
                    {
                        name: 'java'
                    },
                    {
                        name: 'react'
                    }
                ]
            }
        ]

        wrapper.setState({
            users: users
        })
        wrapper.instance().onDeleteCourse(props.column.dataKey, props.cellData.userId, props.cellData.name);
        expect(wrapper.state().users[0].Trainer).toHaveLength(2);
    })

    it('should check if users are selected', () => {
        const wrapper = shallow(<UserDetail />).dive();
        const props = {
            cellData: {
                userId: 1,
            },

            users: [
                {
                    id: 1,
                    checkedList: {
                        selected: true
                    },
                    firstName: 'soundarya',
                    lastName: 'atgondan'
                }
            ]
        }

        wrapper.setState({
            users: props.users,
            selectAllClicked: true,
        })

        wrapper.instance().onUserSelected(props.users[0].id);
        wrapper.instance().onSubmit(props.cellData);

        expect(wrapper.state().users[0].checkedList.selected).toEqual(false);
    })

    it('should check if users are selected with invalid id', () => {
        const wrapper = shallow(<UserDetail />).dive();
        const props = {
            cellData: {
                userId: 2,
            },

            users: [
                {
                    id: 1,
                    checkedList: {
                        selected: false
                    },
                    firstName: 'soundarya',
                    lastName: 'atgondan'
                }
            ]
        }

        wrapper.setState({
            users: props.users,
            selectAllClicked: true,
        })

        wrapper.instance().onUserSelected(props.users[0].id);
        wrapper.instance().onSubmit(props.cellData);

        expect(wrapper.state().users[0].checkedList.selected).toEqual(true);
    })

    it('should check if all users are selected', () => {
        const wrapper = shallow(<UserDetail />).dive();
        const props = {
            cellData: {
                userId: 1,
            },

            users: [
                {
                    id: 1,
                    checkedList: {
                        selected: false
                    },
                    firstName: 'soundarya',
                    lastName: 'atgondan'
                }
            ]
        }

        wrapper.setState({
            users: props.users,
            selectAllClicked: false,
        })

        wrapper.instance().onUserSelected(props.users[0].id);
        wrapper.instance().onSubmit(props.cellData);

        expect(wrapper.state().userList).toHaveLength(props.users.length);
        expect(wrapper.state().selectedUsers).toStrictEqual(props.users[0]);
        expect(wrapper.state().users[0].checkedList.selected).toEqual(true);
    })

    it('Should select one or more users when the checkbox is clicked', () => {
        const wrapper = shallow(<UserDetail />).dive();
        const props = {
            cellData: {
                userId: 1,
            },

            users: [
                {
                    id: 1,
                    checkedList: {
                        selected: true
                    },
                    firstName: 'soundarya',
                    lastName: 'atgondan'
                }
            ]
        }

        wrapper.setState({
            users: props.users,
            selectAllClicked: false,
        })

        wrapper.instance().onUserSelected(props.users[0].id);
        wrapper.instance().onSubmit(props.users);

        expect(wrapper.state().userList).toHaveLength(props.users.length);
        expect(wrapper.state().selectedUsers).toStrictEqual(props.users[0]);
        expect(wrapper.state().users[0].checkedList.selected).toEqual(false);
    })

    it('Should select one or more users when the checkbox is clicked', () => {
        const wrapper = shallow(<UserDetail />).dive();
        const props = {
            cellData: {
                userId: 2,
            },

            users: [
                {
                    id: 1,
                    checkedList: {
                        selected: true
                    },
                    firstName: 'soundarya',
                    lastName: 'atgondan'
                }
            ]
        }

        wrapper.setState({
            users: props.users,
            selectAllClicked: false,
        })

        wrapper.instance().onSubmit(props.cellData);

        expect(wrapper.state().userList).toHaveLength(0);
        expect(wrapper.state().selectedUsers).toEqual({});
        expect(wrapper.state().users[0].checkedList.selected).toEqual(true);
    })

    it('Should select one or more users when the checkbox is clicked', () => {
        const wrapper = shallow(<UserDetail />).dive();
        const props = {
            cellData: {
                userId: 2,
            },

            users: [
                {
                    id: 1,
                    checkedList: {
                        selected: true
                    },
                    firstName: 'soundarya',
                    lastName: 'atgondan'
                }
            ]
        }

        wrapper.setState({
            users: props.users,
            selectAllClicked: false,
        })

        wrapper.instance().onSubmit(props.cellData);

        expect(wrapper.state().userList).toHaveLength(0);
        expect(wrapper.state().selectedUsers).toEqual({});
        expect(wrapper.state().users[0].checkedList.selected).toEqual(true);
    })

    it('should invoke handleSelectRole() on selecting a role - positive', () => {
        const wrapper = shallow(<UserDetail />).dive();
        const props = {
            event: {
                target: {
                    name: 'RMO',
                    checked: true
                }
            }
        }

        expect(wrapper.state().isRoleSelected).toBeFalsy();
        expect(wrapper.state().selectedRole).toHaveLength(0);

        wrapper.instance().onSelectRole(props.event.target.name, props.event.target.checked);

        expect(wrapper.state().isRoleSelected).toBeTruthy();
        expect(wrapper.state().selectedRole).toHaveLength(1);
    })

    it('should invoke handleSelectRole() on deselecting a role  negative', () => {
        const wrapper = shallow(<UserDetail />).dive();
        const props = {
            event: {
                target: {
                    name: 'RMO',
                    checked: false
                }
            }
        }

        expect(wrapper.state().isRoleSelected).toBeFalsy();
        expect(wrapper.state().selectedRole).toHaveLength(0);

        wrapper.instance().onSelectRole(props.event.target.name, props.event.target.checked);

        expect(wrapper.state().isRoleSelected).toBeTruthy();
        expect(wrapper.state().selectedRole).toHaveLength(0);
    })

    it('should invoke handleSelectCourse() on selecting  a course', () => {
        const wrapper = shallow(<UserDetail />).dive();
        const props = {
            course: [
                {
                    value: 1,
                    label: 'BIGDATA',
                    description: 'SomeText',
                    isActive: 'false'
                }
            ],

            role: [
                {
                    name: 'Trainer',
                    id: 1,
                    hasCourse: true
                }
            ],

            courses: [
                {
                    name: 'Java',
                    id: 1
                },
                {
                    name: 'JavaScript',
                    id: 2
                }
            ]

        }

        wrapper.setState({
            roles: props.role,
            selectedRoleCourse: []
        })

        expect(wrapper.state().isCourseSelected).toBeFalsy();
        expect(wrapper.state().selectedRoleCourse).toHaveLength(0);
        console.warn(wrapper.state().selectedRoleCourse);



        wrapper.instance().onSelectCourse(props.course, props.role);

        expect(wrapper.state().roles).toHaveLength(props.role.length);
        expect(wrapper.state().isCourseSelected).toBeTruthy();
        expect(wrapper.state().selectedRoleCourse).toHaveLength(1);
    })

    // it.only('Should render if data is available', () => {
    //     const wrapper = shallow(<UserDetail />).dive();
    //     const users = [
    //         {
    //             individualData: {
    //                 id: 1,
    //                 firstName: 'soundarya',
    //                 lastName: 'Atgondan',
    //                 checkBox: 'false',
    //                 role: [
    //                     {
    //                         name: 'Trainer',
    //                         course: {
    //                             name: 'java',
    //                             userId: 1,
    //                             isActive: false
    //                         }
    //                     },
    //                     {
    //                         name: 'Evaluator',
    //                         course: {
    //                             name: 'java',
    //                             userId: 2,
    //                             isActive: false
    //                         }
    //                     },
    //                     {
    //                         name: 'Author',
    //                         course: {
    //                             name: 'java',
    //                             userId: 3,
    //                             isActive: false
    //                         }
    //                     }
    //                 ]
    //             },    
    //             trainerCourses: [
    //                 {
    //                     name: 'java'
    //                 }
    //             ],
    //             evaluatorCourses: [
    //                 {
    //                     name: 'java'
    //                 }
    //             ],
    //             authorCourses: [
    //                 {
    //                     name: 'java'
    //                 }
    //             ],
    //             misc: [
    //                 {
    //                     name: 'rmo'
    //                 }
    //             ],
    //             checkBox: {
    //                 userId: 1,
    //                 selected: 'false'
    //             },

    //         }
    //     ]
    //     wrapper.setState({
    //         users: users
    //     })

    //     wrapper.instance().componentDidMount();
    //     expect(wrapper.state().users[0].individualData.role[0].name).toEqual('Trainer');

    // })
});
