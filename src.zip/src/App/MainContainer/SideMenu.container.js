import React from 'react';

import classes from './MainContainer.container.scss';

const sideMenu = () => {
    return(
        <div className={classes.sideMenu}>
            <div className={classes.sideMenuIcons}>
                <div className={classes.iconDivider}>
                    <i className='fas fa-tachometer-alt' />
                    <span className={classes.caption}>Dashboard</span>
                </div>
                <div className={classes.iconDivider}>
                    <i className='fas fa-book-open' />
                    <span className={classes.caption}>Course</span>
                </div>
                <div className={classes.iconDivider}>
                    <i className='fas fa-cogs' />
                    <span className={classes.caption}>Settings</span>
                </div>
                <div className={classes.iconDivider}>
                    <i className='fas fa-users' />
                    <span className={classes.caption}>Account</span>
                </div>
            </div>
        </div>
    );
}

export default sideMenu;
