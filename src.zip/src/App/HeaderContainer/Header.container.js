import React from 'react';
import Paper from '@material-ui/core/Paper';
import InputBase from '@material-ui/core/InputBase';
import IconButton from '@material-ui/core/IconButton';
import SearchIcon from '@material-ui/icons/Search';

import logo from '../assets/logo.png';
import classes from './Header.container.scss';

const header = () => {
    return(
        <div className={classes.headerWrapper}>
            <a href='#' className={classes.headerBrand}>
                <img src={logo} className={classes.logo} />
            </a>
            <div className={classes.headerSearch}>
                <Paper className={classes.searchWrapper} elevation={1}>
                    <InputBase className={classes.inputSearch} placeholder='Search for course' />
                    <IconButton className={classes.iconButton} aria-label='Search'>
                        <SearchIcon />
                    </IconButton>
                </Paper>
            </div>
            <div className={classes.headerNotification}>
                <span className='fas fa-comment-alt'>
                    <span className={classes.badge}>3</span>
                </span>
                <span className='fas fa-comments'>
                    <span className={classes.badge}>3</span>
                </span>
            </div>
        </div>
    );
}

export default header;
