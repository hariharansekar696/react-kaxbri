import React, { Component } from 'react';
import Button from '@material-ui/core/Button';
import axios from 'axios';
import 'react-toastify/dist/ReactToastify.css';

import classes from './AddCourse.scss';
import HttpRequest from '../service/HttpRequest';
import Input from '../../lib/Input/landInput.component';
import Author from './Author/author.component';
import * as constants from './AddCourse.constants';
import * as appConstants from '../App.constants';
import ToastService from '../../lib/toaster/LandToastService';

/*
 * Created Date: Monday, February 25th 2019, 9:23:08 pm
 * Author: shahul.shaik
 * 
 */

class AddCourse extends Component {
    state = {
        addAuthorForm: {
            courseName: {
                label: constants.COURSE_NAME,
                elementType: constants.INPUT,
                elementConfig: {
                    type: constants.TEXT,
                    maxLength: 40
                },
                value: constants.EMPTY_STRING,
                validation: {
                    required: true,
                    maxLength: 40,
                },
                valid: false,
                touched: false,
                error: null,
                errorMessage: null,
                hint: 'only 40 characters allowed ',
            },
            addThumbnail: {
                label: constants.ADD_THUMBNAIL,
                elementType: constants.UPLOAD,
                file: null,
                image: constants.EMPTY_STRING,
                elementConfig: {
                    type: constants.FILE,
                    accept: constants.ACCEPTED_IMAGE_FORMATS
                },
                validation: {
                    fileSize: constants.FILE_SIZE,
                    imageType: true
                },
                valid: false,
                touched: false,
                error: null,
                errorMessage: null,
            },
            search: {
                elementType: constants.SEARCH,
                elementConfig: {
                    type: constants.SEARCH,
                    label: constants.AUTHOR_NAME,
                    hideSuggestion: false,
                },
                validation: {
                    onlyAlphabets: true,
                },
                value: constants.EMPTY_STRING,
                suggest: [],
                valid: false,
                touched: false,
                errorMessage: null,
                error: null,
            },
            courseAssign: {
                elementType: constants.SELECT,
                elementConfig: {
                    type: constants.SELECT,
                },
                value: true,
                valid: true,
                touched: false,
            },
        },
        formIsValid: false,
        selectedAuthors: [],
        uploadServiceResponse: null,
    }

    errorHandler = (isValid, updateElement, errorMessage) => {
        if (!isValid) {
            updateElement.error = !isValid;
            updateElement.errorMessage = errorMessage;
        }
    }

    checkValidity = (value, rules, updateElement) => {
        let isValid = true;
        if (!rules) {
            return true;
        }

        if (rules.maxLength) {
            isValid = (value.length !== rules.maxLength);
            this.errorHandler(isValid, updateElement, constants.MAX_LIMIT_REACHED);
        }

        if (rules.fileSize) {
            isValid = value.size < constants.FILE_SIZE && isValid;
            this.errorHandler(isValid, updateElement, constants.MAX_FILE_SIZE);
        }

        if (rules.imageType && isValid) {
            isValid = (value.type === constants.IMAGE_JPEG || value.type === constants.IMAGE_PNG) && isValid;
            this.errorHandler(isValid, updateElement, constants.FILE_FORMATS_ACCEPTED);
        }

        if (rules.onlyAlphabets) {
            if (value.trim() === constants.EMPTY_STRING) {
                return isValid = false; 
            } else {
                const containsAlphabets = appConstants.REGEX_ALPHABETS;
                isValid = containsAlphabets.test(value) && isValid;
                this.errorHandler(isValid, updateElement, constants.NAME_VALIDATION);
            }
        }

        if (rules.required && isValid) {
            isValid = !(value.trim() === constants.EMPTY_STRING && isValid);
            this.errorHandler(isValid, updateElement, constants.REQUIRED_MSG);
        }
        return isValid;
    }

    getFormValue = (event, updateElement) => {
        if (event.target.type === constants.FILE) {
            updateElement.file = event.target.files[0];
            updateElement.valid = this.checkValidity(updateElement.file, updateElement.validation, updateElement);
        } else {
            updateElement.value = event.target.value;
            updateElement.valid = this.checkValidity(updateElement.value, updateElement.validation, updateElement);
        }
        return updateElement;
    }

    fileInputHandler = (updateElement, event) => {
        if ((updateElement.elementConfig.type === constants.FILE) && updateElement.valid) {
            updateElement.image = URL.createObjectURL(event.target.files[0]);
        } else if (updateElement.elementConfig.type === constants.FILE){
            updateElement.image = constants.EMPTY_STRING;
        }
        return updateElement;
    }

    searchHandler = (addAuthorForm, inputIdentifier, updateElement) => {
        if ((updateElement.elementConfig.type === constants.SEARCH)) {
            if (updateElement.valid) {
                let searchresponse = HttpRequest.get();
                searchresponse.then(resp => {
                    updateElement.suggest = resp.data;
                    updateElement.elementConfig.hideSuggestion = false;
                    addAuthorForm[inputIdentifier] = updateElement;
                    this.setState({addAuthorForm: addAuthorForm});
                });
            } else {
                updateElement.elementConfig.hideSuggestion = true;
            }
            updateElement.valid = true;
        }
        return updateElement;
    }

    inputChangedHandler = (event, inputIdentifier) => {
        const addAuthorForm = {...this.state.addAuthorForm};
        let updateElement = {...addAuthorForm[inputIdentifier]};

        updateElement = this.getFormValue(event, updateElement);

        if (updateElement.valid) {
            updateElement.error = null;
            updateElement.errorMessage = null;
        }

        updateElement = this.fileInputHandler(updateElement, event);
        updateElement = this.searchHandler(addAuthorForm, inputIdentifier, updateElement);
        updateElement.touched = true;

        addAuthorForm[inputIdentifier] = updateElement;
        let formIsValid = true;
        for (let inputIdentifier in addAuthorForm) {
            formIsValid = addAuthorForm[inputIdentifier].valid && formIsValid;
        }
        this.setState({addAuthorForm: addAuthorForm, formIsValid: formIsValid});
    }

    authorSelect = (author) => {
        const selectedAuthors = [...this.state.selectedAuthors];
        const addAuthorForm = {...this.state.addAuthorForm};
        const found = selectedAuthors.some(item => item.id === author.id);
        if (found) {
            ToastService.info(constants.INFO_MSG_SAMEAUTHOR);
        } else if (selectedAuthors.length > 9) {
            ToastService.info(constants.INFO_MSG_MAXLIMIT)
        }
        else {
            selectedAuthors.push(author);
            addAuthorForm.search.value = constants.EMPTY_STRING;
            addAuthorForm.search.elementConfig.hideSuggestion = true;
            this.setState({selectedAuthors: selectedAuthors, addAuthorForm: addAuthorForm});
        }
    }

    handleKeyPress = (event) => {
        if (event.keyCode === 27) {
            let addAuthorForm = {...this.state.addAuthorForm};
            addAuthorForm.search.elementConfig.hideSuggestion = true;
            addAuthorForm.search.value = constants.EMPTY_STRING;
            this.setState({ addAuthorForm: addAuthorForm });
        }
    }

    removeAuthor = (author) => {
        const selectedAuthors = [...this.state.selectedAuthors];
        const index = selectedAuthors.indexOf(author);
        selectedAuthors.splice(index, 1);
        this.setState({selectedAuthors: selectedAuthors});
    }

    handleMouseOver = () => {
        this.setState({onSearch: true});
    }
    
    handleMouseOut = () => {
        this.setState({onSearch: false});
    }

    handleBlur = () => {
        if (!this.state.onSearch) {
            let addAuthorForm = {...this.state.addAuthorForm};
            addAuthorForm.search.elementConfig.hideSuggestion = true;
            this.setState({ addAuthorForm: addAuthorForm });
        }
    }

    onOffsetReached = (flag) => {
        let addAuthorForm = {...this.state.addAuthorForm};
        let search = {...addAuthorForm[constants.SEARCH]};
        if (flag) {
            let response = HttpRequest.get();
            response.then(resp => {
                resp.data.map(data => {
                    search.suggest.push(data);
                });
            });
        }
        addAuthorForm[constants.SEARCH] = search;
        this.setState({ addAuthorForm: addAuthorForm });
    }

    onFormSubmit = (event) => {
        event.preventDefault();
        let formData = new FormData();
        formData.append('file', this.state.addAuthorForm.addThumbnail.file);

        let payLoad = {};
        payLoad['courseName'] = this.state.addAuthorForm.courseName.value;
        payLoad['isSelfAssignable'] = this.state.addAuthorForm.courseAssign.value;
        payLoad['users'] = this.state.selectedAuthors

        // axios.post('http://192.168.2.160:8080/land-api/api/v1/resource', formData, {
        //      headers: {
        //         'Access-Control-Allow-Origin': '*',
        //         'Content-Type': 'multipart/form-data'
        //      }
        // })
        // .then(resp => {
        //     payLoad['thumbnail'] = resp.data;
        //     axios.post('http://192.168.2.160:8080/land-api/api/v1/resource', payLoad)
        //          .then(ToastService.success(<p>{constants.SUCCESS_MSG_ADDCOURSE}<br/> <a href=''>edit authors</a></p>);
        //                this.props.history.push('/'));
        // });
    }

    onCancel = () => {
        //redirect to previous page
    }

    render() {
        const elements = [];
        const formElementsArray = [];
        for (let key in this.state.addAuthorForm) {
            formElementsArray.push({
                id: key,
                config: this.state.addAuthorForm[key]
            });
        }

        formElementsArray.map(formElement => {
            elements.push(
            <Input
              key={formElement.id}
              clicked={this.authorSelect}
              image={this.state.addAuthorForm.addThumbnail.image}
              offsetReached={this.onOffsetReached}
              onKeyDown={this.handleKeyPress}
              value={formElement.config.value}
              label={formElement.config.label}
              error={formElement.config.error}
              hint={formElement.config.hint}
              suggest={formElement.config.suggest}
              elementType={formElement.config.elementType}
              errorMessage={formElement.config.errorMessage}
              elementConfig={formElement.config.elementConfig}
              onFocus={this.onFocusSearch}
              onBlur={this.handleBlur}
              onMouseOver={this.handleMouseOver}
              onMouseOut={this.handleMouseOut}
              changed={(event) => this.inputChangedHandler(event, formElement.id)} />)
        });

        const otherElements = elements.splice(0,2);

        const form = (
            <form onSubmit={this.onFormSubmit} className={classes.form}>
                <div className={classes.itemsHolder}>
                    <div className={classes.topSegment}>
                        {otherElements.map(element => element)}
                    </div>
                    <div className={classes.bottomSegment}>
                        {elements.map(element => element)}
                    </div>
                    <div className={classes.authorHolder}>
                        <div className={classes.container}>
                            <Author
                              authors={this.state.selectedAuthors}
                              remove={this.removeAuthor}
                            />
                        </div>
                    </div>
                    <div className={classes.submissionButton}>
                        <div className={classes.addCourseButton} > 
                            <Button
                              type={constants.SUBMIT}
                              color={constants.PRIMARY}
                              variant={constants.CONTAINED}
                              className={classes.textFormat}
                              disabled={!(this.state.formIsValid && (this.state.selectedAuthors.length > 0))}>
                              Add Course
                            </Button>
                        </div>
                        <div className={classes.cancelButton}>
                            <Button
                              className={classes.textFormat}
                              color={constants.PRIMARY}
                              variant={constants.CONTAINED}
                              onClick={this.onCancel}>
                              Cancel
                            </Button>
                        </div>
                    </div>
                </div>
            </form>);
        return (
            <div className={classes.AddCourse}>
                {form}
            </div>
        );
    }
}

export default AddCourse;
