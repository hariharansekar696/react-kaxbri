export const MAX_LIMIT_REACHED = 'maximum limit 40 characters'
export const MAX_FILE_SIZE = 'max filesize should be < 5Mb';
export const REQUIRED_MSG = 'course name cannot be empty';
export const NAME_VALIDATION = 'name should have only alphabets';
export const FILE_FORMATS_ACCEPTED = 'only .png and .jpeg formats are accepted';

export const AUTHOR_NAME = 'Author Name';
export const ADD_THUMBNAIL = 'Add Thumbnail';
export const AUTHOR_COMPONENT = 'authorComponent';
export const AUTHORS = 'authors'
export const ACCEPTED_IMAGE_FORMATS = '.png, .jpg';
export const AUTHOR = 'author';

export const COURSE_NAME = 'Course Name';
export const COURSE_NAME_VAR = 'courseName';
export const CONTAINED = 'contained'

export const EMPTY_STRING = '';
export const EXTENDED_FAB = 'extendedFab'
export const ERROR = 'error';

export const FILE = 'file';
export const FILE_SIZE = '40000000';

export const INPUT = 'input';
export const IMAGE_JPEG = 'image/jpeg';
export const IMAGE_PNG = 'image/png';

export const PRIMARY = 'primary';

export const SEARCH = 'search';
export const SELECT = 'select';
export const SUBMIT = 'submit';
export const SECONDARY = 'secondary';

export const TEXT = 'text';
export const TOP_RIGHT = 'top-right';
export const SUCCESS_MSG_ADDCOURSE = 'Course added successfully!!';
export const INFO_MSG_SAMEAUTHOR = 'Author already added';
export const INFO_MSG_MAXLIMIT = 'Maximum authors added';
export const THUMBNAIL_VAR = 'thumbnail';

export const UPLOAD = 'upload';

export const VALUE = ' ';
