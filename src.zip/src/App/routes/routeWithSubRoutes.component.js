import React from 'react';
import { Route } from 'react-router-dom';

/*
 * File: routeWithSubRoutes.component.js
 * Project: land-react-ui
 * File Created: Thursday, 28th March 2019 6:29:32 pm
 * Author: Shahul Hameed M D (shahul.shaik@object-frontier.com)
 * -----
 * Last Modified: Friday, 3rd May 2019 11:15:19 am
 * Modified By: Shahul Hameed M D (shahul.shaik@object-frontier.com)
 * -----
 * Copyright 2019 Object Frontier Software Pvt. Ltd
 */

const routeWithSubRoutes = (route) => (
    <Route path={route.path} render={(props) => (
      <route.component {...props} routes={route.routes}/>
    )}/>
);

export default routeWithSubRoutes;