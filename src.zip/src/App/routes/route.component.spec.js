import React from 'react';
import { Route, Switch, Redirect } from 'react-router-dom';

import { configure, shallow } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

import Routes from './route.component';

configure({adapter: new Adapter()});

describe('<Routes />', () => {
    it('should return a single <Switch />', () => {
        let wrapper = shallow(<Routes />)
        expect(wrapper.find(Switch)).toHaveLength(1);
    });

    it('should conatain <Redirect /> of length 1 ', () => {
        let wrapper = shallow(<Routes />);
        expect(wrapper.find(Redirect)).toHaveLength(1);
    });

    it('should contain <Route /> of lenght 1', () => {
        let wrapper = shallow(<Routes />);
        expect(wrapper.find(Route)).toHaveLength(1);
    })
});
