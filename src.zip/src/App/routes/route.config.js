import Addcourse from '../AddCourse/AddCourse.container';
import UserDetail from '../AssignRoles/UserDetail/UserDetail.component';

/*
 * File: route.config.js
 * Project: land-react-ui
 * File Created: Monday, 25th March 2019 10:06:30 am
 * Author: Shahul Hameed M D (shahul.shaik@object-frontier.com)
 * -----
 * Last Modified: Monday, 3rd June 2019 2:20:58 pm
 * Modified By: soundarya.atgondan (soundarya.atgondan@object-frontier.com>)
 * -----
 * Copyright 2019 Object Frontier Software Pvt. Ltd
 */

export default [
    {
        component: Addcourse,
        path: '/addcourse',
        routes: []
    },
    {
        component: UserDetail,
        path: '/userdetail',
        routes: []
    }
];
